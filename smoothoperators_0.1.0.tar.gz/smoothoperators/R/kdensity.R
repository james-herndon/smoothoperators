#' Multivarite Density Estimation with Leave-one-out (loo=0) is turned off
#'
#' See Chapter 2
#'
#' @param x matrix
#'
#' @param kernel  "epanechnikov", "biweight", "triweight", "gaussian"
#'
#' @return list
#'
#' @examples
#' dat <- read.csv("/co2.emissions.csv", header=TRUE)
#'
#' attach(dat)
#'
#' pcemission.1960 <- sort(as.matrix(pcemission.1960))
#'
#' n <- length(pcemission.1960)
#'
#' bw.1960 <- 1.06*sd(pcemission.1960)*n^(-.2)
#'
#' f.1960 <- kdensity(pcemission.1960,bw.1960)$est.den
#'
#' @export





kdensity <- function(x,bw=NULL,loo=0,kernel="gaussian"){

  x <- as.matrix(x)
  q <- ncol(x)
  n <- nrow(x)
  ones <- rep(1,n)

  if(kernel=="epanechnikov") {
    kk <- function(g) ifelse(abs(g)<=1, 0.75*(1-g^2), 0)
  }
  if(kernel=="biweight") {
    kk <- function(g) ifelse(abs(g)<=1, (15/16)*(1-g^2)^2, 0)
  }
  if(kernel=="triweight") {
    kk <- function(g) ifelse(abs(g)<=1, (35/32)*(1-g^2)^3, 0)
  }
  if(kernel=="gaussian") {
    kk <- function(g) (1/sqrt(2*pi))*exp(-0.5*g^2)
  }

  if(is.null(bw)==TRUE){

    if(kernel=="epanechnikov") {
      bw <- 2.345*apply(x,2,sd)*n^(-1/(4+q))
    }
    if(kernel=="biweight") {
      bw <- 2.778*apply(x,2,sd)*n^(-1/(4+q))
    }
    if(kernel=="triweight") {
      bw <- 3.154*apply(x,2,sd)*n^(-1/(4+q))
    }
    if(kernel=="gaussian") {
      bw <- 1.059*apply(x,2,sd)*n^(-1/(4+q))
    }

  }

  ## creating product bandwidths for cont variables (joint dist only)
  bw.prod <- 1

  for (j in 1:q){

    bw.prod <- bw.prod*bw[j]

  }

  ## Creating and storing the kernel matricies
  KK.store <- matrix(0,nrow=n,ncol=n)

  ## n by n kernel matrix can be used later
  for (j in 1:n){

    KK <- ones

    for (jj in 1:q){


      dx <- (x[,jj] - x[j,jj])/bw[jj]
      KK <- KK*kk(dx)

    }

    KK.store[,j] <- KK
    if (loo==1){ KK.store[j,j] <- 0 }

  }

  ## Estimating the density f
  est.den <- solve((n-1)*bw.prod)*colSums(KK.store)

  ## Listing items to send back
  return.list <- list(est.den=est.den,bw=bw,KK.store=KK.store)

  return(return.list)

}
