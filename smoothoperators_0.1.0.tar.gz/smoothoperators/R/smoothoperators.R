#' Smoothoperators Package
#'
#' This package contains the code used in Henderson & Parmeter's textbook
#' "Applied Nonparametric Econometrics." Original code by Henderson and Parmeters avilable at
#' http://www.the-smooth-operators.com
#'
#' @docType package
#'
#' @author James Herndon \email{vandymarine@gmail.com}
#'
#' @name smoothoperators
#'
#'
NULL
